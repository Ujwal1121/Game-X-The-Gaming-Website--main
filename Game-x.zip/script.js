// const header = document.querySelector("header");
// const header_title = document.getElementById("header_title");
// const d_btn1 = document.getElementById("d_btn1");
// const d_btn2 = document.getElementById("d_btn2");
// const slider_btn = document.querySelectorAll(".dot");

// const backimg = {
//   fimg: "img/egypt-slider.jpg",
//   simg: "img/sliderimg2.jpg",
//   timg: "img/racecar.jpg",
// };

// const slider_load = (index) => {
//   const images = [backimg.fimg, backimg.simg, backimg.timg];
//   const titles = ["EGYPT AND WORLD", "RISE OF THE TOMB RAIDER", "HORIZON 4"];

//   header.style.background = `url(${images[index]}) no-repeat center center/cover`;
//   header_title.innerText = titles[index];

//   slider_btn.forEach((btn, i) => {
//     btn.style.background = i === index ? "#fff" : "rgb(184,184,184,0.1)";
//   });

//   d_btn1.href = "#";
//   d_btn2.href = "#";
// };

// let currentIndex = 0;

// const nextSlide = () => {
//   currentIndex = (currentIndex + 1) % slider_btn.length;
//   slider_load(currentIndex);
// };

// slider_btn.forEach((btn, index) => {
//   btn.addEventListener("click", () => {
//     currentIndex = index;
//     slider_load(currentIndex);
//   });
// });

// setInterval(nextSlide, 10000);
// slider_load(currentIndex);

// Select the header element to set the background image dynamically for the slider.
const header = document.querySelector("header");

// Select the title element inside the header to display slide-specific titles.
const header_title = document.getElementById("header_title");

// Get reference to the first and second buttons (could be for actions like download or navigation).
const d_btn1 = document.getElementById("d_btn1");
const d_btn2 = document.getElementById("d_btn2");

// Select all the dot elements representing slider indicators.
const slider_btn = document.querySelectorAll(".dot");

// Object containing the paths to background images for the slider.
const backimg = {
  fimg: "img/egypt-slider.jpg", // Path to the first image.
  simg: "img/sliderimg2.jpg", // Path to the second image.
  timg: "img/racecar.jpg", // Path to the third image.
};

// Function to update the slider with the current slide based on the index.
const slider_load = (index) => {
  // Array of image paths for the slider.
  const images = [backimg.fimg, backimg.simg, backimg.timg];

  // Array of titles corresponding to each image in the slider.
  const titles = ["EGYPT AND WORLD", "RISE OF THE TOMB RAIDER", "HORIZON 4"];

  // Set the header background to the current slide's image.
  header.style.background = `url(${images[index]}) no-repeat center center/cover`;

  // Update the header title with the corresponding slide's title.
  header_title.innerText = titles[index];

  // Update the dot indicators: highlight the active dot and dim the others.
  slider_btn.forEach((btn, i) => {
    btn.style.background = i === index ? "#fff" : "rgba(184, 184, 184, 0.1)";
  });

  // Set the href attributes for the action buttons (can be customized).
  d_btn1.href = "#";
  d_btn2.href = "#";
};

// Variable to track the current slide index.
let currentIndex = 0;

// Function to move to the next slide.
const nextSlide = () => {
  // Increment the index and loop back to the first slide if at the end.
  currentIndex = (currentIndex + 1) % slider_btn.length;
  // Load the slide corresponding to the updated index.
  slider_load(currentIndex);
};

// Add click event listeners to each slider dot to switch slides on click.
slider_btn.forEach((btn, index) => {
  btn.addEventListener("click", () => {
    // Update the current index to the clicked dot's index.
    currentIndex = index;
    // Load the slide corresponding to the clicked dot.
    slider_load(currentIndex);
  });
});

// Automatically switch to the next slide every 10 seconds.
setInterval(nextSlide, 10000);

// Load the initial slide (first slide) when the page is loaded.
slider_load(currentIndex);
